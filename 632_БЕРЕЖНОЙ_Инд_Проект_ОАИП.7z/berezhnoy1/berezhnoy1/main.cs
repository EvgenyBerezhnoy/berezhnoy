﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace berezhnoy1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dnevnik_Click(object sender, EventArgs e)
        {
            Hide();
            Form2 дневник = new Form2();
            дневник.ShowDialog();
            Close();
        }

        private void parent_Click(object sender, EventArgs e)
        {
            Hide();
            infoparent дневник = new infoparent ();
            дневник.ShowDialog();
            Close();
        }

        private void ocenite_Click(object sender, EventArgs e) 
        {
            Hide();
            evaluation дневник = new evaluation();
            дневник.ShowDialog();
            Close();
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dnevnikstud_Click(object sender, EventArgs e)
        {

        }

        private void panelinf_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
