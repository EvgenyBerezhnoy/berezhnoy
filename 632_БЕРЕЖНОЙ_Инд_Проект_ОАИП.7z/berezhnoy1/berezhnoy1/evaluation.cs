﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace berezhnoy1
{
    public partial class evaluation : Form
    {
        public evaluation()
        {
            InitializeComponent();
        }

        private void great_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void exit_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 дневник = new Form1();
            дневник.ShowDialog();
            Close();
        }

        private void send_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Спасибо за отзыв!");
        }

        private void evaluation_Load(object sender, EventArgs e)
        {

        }

        private void otziv_TextChanged(object sender, EventArgs e)
        {

        }

        private void sendi_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Спасибо за отзыв!");
        }

        private void nice_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void udovletvoritelno_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bad_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
