﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace berezhnoy1
{
    public partial class vichkovskiy : Form
    {
        public vichkovskiy()
        {
            InitializeComponent();
        }

        private void information_Click(object sender, EventArgs e)
        {
            {
                string outputstr = label30.Text;
                SaveFileDialog saveFile = new SaveFileDialog();
                saveFile.DefaultExt = ".txt";
                saveFile.Filter = "text files|*.txt";
                if (saveFile.ShowDialog() == System.Windows.Forms.DialogResult.OK && saveFile.FileName.Length > 0)
                {
                    using (StreamWriter kk = new StreamWriter(saveFile.FileName, true))
                    {
                        kk.WriteLine(outputstr);

                        kk.Close();
                    }
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Hide();
            Form2 дневник = new Form2();
            дневник.ShowDialog();
            Close();
        }

        private void ocenki_Click(object sender, EventArgs e)
        {

        }

        private void vichkovskiy_Load(object sender, EventArgs e)
        {

        }
    }
}
