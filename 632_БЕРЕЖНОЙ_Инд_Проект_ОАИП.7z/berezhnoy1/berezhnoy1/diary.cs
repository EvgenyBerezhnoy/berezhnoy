﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace berezhnoy1
{
    public partial class Form2 : Form
    {
       
        string[] students533 = { "Шпак А.Ю" };
               
        string[] groups =
      {"632-Д9-2ИСП",
       "533-КД9-3ИНБ",
        };
        string[] students632 =
      { "Вичковский С.Р" };
        public Form2()
        {
            InitializeComponent();
            int i;
            for (i = 0; i < groups.Length; i++)
            {
                vgroup.Items.Add(groups[i]);
            }


        }


        private void Forma2_Load(object sender, EventArgs e)
        {


        }

        private void vgroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            int m;
            vstud.Items.Clear();
            vstud.Text = null;
            if (vgroup.Text == "632-Д9-2ИСП")
            {


                for (m = 0; m < students632.Length; m++)
                {
                    vstud.Items.Add(students632[m]);
                }


            }
            else
            {
                for (m = 0; m < students533.Length; m++)
                {
                    vstud.Items.Add(students533[m]);
                }
            }
        }

        

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            Hide();
            Form1 дневник = new Form1();
            дневник.ShowDialog();
            Close();
        }

        private void vstud_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkgroup_Click(object sender, EventArgs e)
        {

        }

        private void dnevnikstud_Click(object sender, EventArgs e)
        {

        }

        private void form_Click(object sender, EventArgs e)
        {
            string b = vstud.Text;
            if (b == "Вичковский С.Р")
            {
                vichkovskiy form5 = new vichkovskiy();
                form5.Show();


            }
            else if (b == "Шпак А.Ю")
            {
                shpak form6 = new shpak();
                form6.Show();
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
             
        }

        private void checkgroup_Click_1(object sender, EventArgs e)
        {

        }

        private void checkstudent_Click(object sender, EventArgs e)
        {

        }

        private void panelif_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}