﻿namespace berezhnoy1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dnevnikstud = new System.Windows.Forms.Label();
            this.dnevnik = new System.Windows.Forms.Button();
            this.ocenite = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.parent = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.dnevnikstud);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panel1.Size = new System.Drawing.Size(800, 63);
            this.panel1.TabIndex = 10;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panelinf_Paint);
            // 
            // dnevnikstud
            // 
            this.dnevnikstud.AutoSize = true;
            this.dnevnikstud.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dnevnikstud.ForeColor = System.Drawing.Color.Black;
            this.dnevnikstud.Location = new System.Drawing.Point(221, 9);
            this.dnevnikstud.Name = "dnevnikstud";
            this.dnevnikstud.Size = new System.Drawing.Size(337, 42);
            this.dnevnikstud.TabIndex = 7;
            this.dnevnikstud.Text = "Дневник студента";
            this.dnevnikstud.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.dnevnikstud.Click += new System.EventHandler(this.dnevnikstud_Click);
            // 
            // dnevnik
            // 
            this.dnevnik.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.dnevnik.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dnevnik.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dnevnik.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dnevnik.Location = new System.Drawing.Point(586, 284);
            this.dnevnik.Name = "dnevnik";
            this.dnevnik.Size = new System.Drawing.Size(202, 28);
            this.dnevnik.TabIndex = 18;
            this.dnevnik.Text = "Дневник";
            this.dnevnik.UseVisualStyleBackColor = false;
            this.dnevnik.Click += new System.EventHandler(this.dnevnik_Click);
            // 
            // ocenite
            // 
            this.ocenite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.ocenite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ocenite.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ocenite.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ocenite.Location = new System.Drawing.Point(586, 352);
            this.ocenite.Name = "ocenite";
            this.ocenite.Size = new System.Drawing.Size(202, 28);
            this.ocenite.TabIndex = 20;
            this.ocenite.Text = "Оцените Нас";
            this.ocenite.UseVisualStyleBackColor = false;
            this.ocenite.Click += new System.EventHandler(this.ocenite_Click);
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.exit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.exit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit.Location = new System.Drawing.Point(586, 386);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(202, 28);
            this.exit.TabIndex = 21;
            this.exit.Text = "Выход";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // parent
            // 
            this.parent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.parent.Cursor = System.Windows.Forms.Cursors.Hand;
            this.parent.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.parent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.parent.Location = new System.Drawing.Point(586, 318);
            this.parent.Name = "parent";
            this.parent.Size = new System.Drawing.Size(202, 28);
            this.parent.TabIndex = 23;
            this.parent.Text = "Для пользователей";
            this.parent.UseVisualStyleBackColor = false;
            this.parent.Click += new System.EventHandler(this.parent_Click);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.Location = new System.Drawing.Point(140, 142);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(231, 204);
            this.panel2.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(186)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.parent);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.ocenite);
            this.Controls.Add(this.dnevnik);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Дневник студента";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label dnevnikstud;
        private System.Windows.Forms.Button dnevnik;
        private System.Windows.Forms.Button ocenite;
        private System.Windows.Forms.Button exit;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button parent;
    }
}

