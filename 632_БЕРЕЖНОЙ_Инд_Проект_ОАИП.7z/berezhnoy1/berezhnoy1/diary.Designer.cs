﻿namespace berezhnoy1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dnevnikstud = new System.Windows.Forms.Label();
            this.checkstudent = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkgroup = new System.Windows.Forms.Label();
            this.form = new System.Windows.Forms.Button();
            this.vstud = new System.Windows.Forms.ComboBox();
            this.vgroup = new System.Windows.Forms.ComboBox();
            this.back = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.dnevnikstud);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 63);
            this.panel1.TabIndex = 10;
          
            // 
            // dnevnikstud
            // 
            this.dnevnikstud.AutoSize = true;
            this.dnevnikstud.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dnevnikstud.ForeColor = System.Drawing.Color.Black;
            this.dnevnikstud.Location = new System.Drawing.Point(221, 9);
            this.dnevnikstud.Name = "dnevnikstud";
            this.dnevnikstud.Size = new System.Drawing.Size(337, 42);
            this.dnevnikstud.TabIndex = 7;
            this.dnevnikstud.Text = "Дневник студента";
            this.dnevnikstud.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkstudent
            // 
            this.checkstudent.AutoSize = true;
            this.checkstudent.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkstudent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkstudent.ForeColor = System.Drawing.Color.Black;
            this.checkstudent.Location = new System.Drawing.Point(201, 181);
            this.checkstudent.Name = "checkstudent";
            this.checkstudent.Size = new System.Drawing.Size(143, 18);
            this.checkstudent.TabIndex = 19;
            this.checkstudent.Text = "Выберите студента";
            this.checkstudent.Click += new System.EventHandler(this.checkstudent_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel4.Location = new System.Drawing.Point(166, 178);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(202, 24);
            this.panel4.TabIndex = 21;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.checkgroup);
            this.panel2.Location = new System.Drawing.Point(166, 126);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(202, 24);
            this.panel2.TabIndex = 20;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // checkgroup
            // 
            this.checkgroup.AutoSize = true;
            this.checkgroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkgroup.ForeColor = System.Drawing.Color.Black;
            this.checkgroup.Location = new System.Drawing.Point(35, 3);
            this.checkgroup.Name = "checkgroup";
            this.checkgroup.Size = new System.Drawing.Size(125, 18);
            this.checkgroup.TabIndex = 11;
            this.checkgroup.Text = "Выберите группу";
            this.checkgroup.Click += new System.EventHandler(this.checkgroup_Click_1);
            // 
            // form
            // 
            this.form.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.form.Cursor = System.Windows.Forms.Cursors.Hand;
            this.form.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.form.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.form.Location = new System.Drawing.Point(166, 230);
            this.form.Name = "form";
            this.form.Size = new System.Drawing.Size(202, 29);
            this.form.TabIndex = 18;
            this.form.Text = "Сформировать";
            this.form.UseVisualStyleBackColor = false;
            this.form.Click += new System.EventHandler(this.form_Click);
            // 
            // vstud
            // 
            this.vstud.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.vstud.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vstud.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.vstud.FormattingEnabled = true;
            this.vstud.Location = new System.Drawing.Point(12, 178);
            this.vstud.Name = "vstud";
            this.vstud.Size = new System.Drawing.Size(121, 24);
            this.vstud.TabIndex = 17;
            // 
            // vgroup
            // 
            this.vgroup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.vgroup.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.vgroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.vgroup.FormattingEnabled = true;
            this.vgroup.Location = new System.Drawing.Point(12, 126);
            this.vgroup.Name = "vgroup";
            this.vgroup.Size = new System.Drawing.Size(121, 24);
            this.vgroup.TabIndex = 16;
            this.vgroup.SelectedIndexChanged += new System.EventHandler(this.vgroup_SelectedIndexChanged);
            // 
            // back
            // 
            this.back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.back.Cursor = System.Windows.Forms.Cursors.Hand;
            this.back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.back.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.back.Location = new System.Drawing.Point(586, 410);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(202, 28);
            this.back.TabIndex = 22;
            this.back.Text = "Назад";
            this.back.UseVisualStyleBackColor = false;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(186)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.back);
            this.Controls.Add(this.checkstudent);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.form);
            this.Controls.Add(this.vstud);
            this.Controls.Add(this.vgroup);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = " Дневник студента";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label dnevnikstud;
        private System.Windows.Forms.Label checkstudent;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label checkgroup;
        private System.Windows.Forms.Button form;
        private System.Windows.Forms.ComboBox vstud;
        private System.Windows.Forms.ComboBox vgroup;
        private System.Windows.Forms.Button back;
    }
}